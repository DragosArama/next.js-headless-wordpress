export default function Index() {
  return (
    <div>
      <h3 className="text-lg leading-6 font-medium text-gray-900">
        Applicant Information
      </h3>
    </div>
  );
}
